package nl.duflex.dxprotoproxykeygen;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Date;

public class HelloController {
    @FXML
    private DatePicker expirationDatePicker;
    @FXML
    private TextArea detailsTextArea;
    @FXML
    private CheckBox httpRestApiEnabledCheckBox;
    @FXML
    private CheckBox modBusSlaveEnabledCheckBox;
    @FXML
    private CheckBox modBusMasterEnabledCheckBox;
    @FXML
    private CheckBox mqttClientEnabledCheckBox;

    @FXML
    public void onGenerateButtonPressed() {
        final LocalDate localExpirationDate = this.expirationDatePicker.getValue();
        final Date expirationDate = localExpirationDate == null ? null : Date.from(
                localExpirationDate.atStartOfDay().toInstant(ZoneOffset.UTC));

        final String details = this.detailsTextArea.getText();

        final boolean httpRestApiEnabled = this.httpRestApiEnabledCheckBox.isSelected();
        final boolean modBusSlaveEnabled = this.modBusSlaveEnabledCheckBox.isSelected();
        final boolean modBusMasterEnabled = this.modBusMasterEnabledCheckBox.isSelected();
        final boolean mqttClientEnabled = mqttClientEnabledCheckBox.isSelected();

        if (!httpRestApiEnabled && !modBusSlaveEnabled && !modBusMasterEnabled && !mqttClientEnabled) {
            final var alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("At least one feature must be enabled!");
            alert.setHeaderText("Cannot generate license");
            alert.show();
            return;
        }

        final var features = new ArrayList<String>();

        if (httpRestApiEnabled) features.add("HTTP_REST_API");
        if (modBusSlaveEnabled) features.add("MODBUS_SLAVE");
        if (modBusMasterEnabled) features.add("MODBUS_MASTER");
        if (mqttClientEnabled) features.add("MQTT");

        var license = new License(features, details, expirationDate);
        var licenseSigner = LicenseSignerFactory.createWithPrivateKeyResource("private.pem");
        var licenseKey = licenseSigner.sign(license);

        final var clipboardContent = new ClipboardContent();
        clipboardContent.putString(licenseKey);

        Clipboard.getSystemClipboard().setContent(clipboardContent);

        final var alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setHeaderText("License generated");
        alert.setContentText("The license has been placed in the system clipboard");
        alert.show();
    }
}