package nl.duflex.dxprotoproxykeygen;

import java.util.Date;
import java.util.List;

public class License {
    private final List<String> features;
    private final String details;
    private final Date expiration;

    public License(final List<String> features, final String details, final Date expiration) {
        this.features = features;
        this.details = details;
        this.expiration = expiration;
    }

    public List<String> getFeatures() {
        return features;
    }

    public String getDetails() {
        return details;
    }

    public Date getExpiration() {
        return expiration;
    }
}
