package nl.duflex.dxprotoproxykeygen;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;

public class LicenseSigner {
    private final Algorithm algorithm;

    public LicenseSigner(final Algorithm algorithm) {
        this.algorithm = algorithm;
    }

    public String sign(final License license) {
        final var builder = JWT.create();

        builder.withClaim("features", license.getFeatures());
        builder.withClaim("details", license.getDetails());

        if (license.getExpiration() != null)
            builder.withExpiresAt(license.getExpiration());

        return builder.sign(this.algorithm);
    }
}
