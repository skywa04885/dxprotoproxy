package nl.duflex.dxprotoproxykeygen;

import com.auth0.jwt.algorithms.Algorithm;

import javax.crypto.Cipher;
import javax.crypto.EncryptedPrivateKeyInfo;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.interfaces.RSAPrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Base64;

public class LicenseSignerFactory {
    public static LicenseSigner createWithPrivateKeyResource(final String resource) {
        try (final var publicKeyFile = ClassLoader.getSystemClassLoader().getResourceAsStream(resource)) {
            if (publicKeyFile == null) throw new Error("Public key resource is missing");

            final var publicKeyString = new String(publicKeyFile.readAllBytes(), StandardCharsets.UTF_8)
                    .replace("-----BEGIN PRIVATE KEY-----", "")
                    .replaceAll(System.lineSeparator(), "")
                    .replace("-----END PRIVATE KEY-----", "");
            final var content = Base64.getDecoder().decode(publicKeyString);

            final var privateKeySpec = new PKCS8EncodedKeySpec(content);
            final var keyFactory = KeyFactory.getInstance("RSA");
            final var privateKey = keyFactory.generatePrivate(privateKeySpec);

            final var algorithm = Algorithm.RSA512((RSAPrivateKey) privateKey);

            return new LicenseSigner(algorithm);
        } catch (final IOException | NoSuchAlgorithmException | InvalidKeySpecException exception) {
            throw new Error("Failed to load public key for license validation, message: " + exception.getMessage());
        }
    }
}
