module nl.duflex.dxprotoproxykeygen {
    requires javafx.controls;
    requires javafx.fxml;
    requires com.auth0.jwt;

    opens nl.duflex.dxprotoproxykeygen to javafx.fxml;
    exports nl.duflex.dxprotoproxykeygen;
}